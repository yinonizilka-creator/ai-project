@echo off
cd /d "%~dp0"
start "" "http://localhost:8765"
node --env-file-if-exists=.env server.cjs
pause
