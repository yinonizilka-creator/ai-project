const fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..'),dir=path.join(root,'cloud/functions/_shared');
fs.mkdirSync(dir,{recursive:true});
fs.copyFileSync(path.join(root,'dist/simulator-engine.js'),path.join(dir,'simulator-engine.js'));
fs.copyFileSync(path.join(root,'dist/market-strategy.js'),path.join(dir,'market-strategy.js'));
fs.writeFileSync(path.join(dir,'sp500-data.mjs'),fs.readFileSync(path.join(root,'services/sp500-data.mjs'),'utf8').replaceAll('../dist/','./'));
fs.writeFileSync(path.join(dir,'market-data.mjs'),fs.readFileSync(path.join(root,'services/market-data.mjs'),'utf8').replace("'../dist/simulator-engine.js'","'./simulator-engine.js'"));
