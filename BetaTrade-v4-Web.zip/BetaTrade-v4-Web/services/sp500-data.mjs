import {normalizeMembers,selectUniverse,middleCandidates} from '../dist/market-strategy.js';
import {collectLiveFrame} from './market-data.mjs';
import {createSimulation} from '../dist/simulator-engine.js';
let snapshotCache=null;
function problem(message,status=409){const error=Error(message);error.status=status;return error}
async function request(endpoint,params,key,fetchImpl){const url='https://financialmodelingprep.com/stable/'+endpoint+'?'+new URLSearchParams({...params,apikey:key});const response=await fetchImpl(url,{signal:AbortSignal.timeout(15000)});if(!response.ok)throw problem('Market-data provider returned HTTP '+response.status+'. Check the key, plan entitlement and quota.');const text=await response.text();if(text.length>10000000)throw problem('Market-data response is too large.');let data;try{data=JSON.parse(text)}catch{throw problem('Market-data provider did not return valid JSON.')}if(!Array.isArray(data))throw problem('The provider did not return this dataset. Index constituents, complete market caps and current quotes must be included in the data plan.');return data;}
async function batchedQuotes(symbols,key,fetchImpl){const result=[];for(let i=0;i<symbols.length;i+=50){result.push(...await request('batch-quote',{symbols:symbols.slice(i,i+50).join(',')},key,fetchImpl))}return result;}
export async function currentSp500({key='',now=Date.now(),fetchImpl=fetch,force=false}={}){
 if(!key)throw problem('Connect an S&P 500 market-data key first. No fixed five-company list or invented prices will be substituted.');
 if(!force&&fetchImpl===fetch&&snapshotCache?.key===key&&now-snapshotCache.at<3600000)return snapshotCache.value;
 const members=await request('sp500-constituent',{},key,fetchImpl);if(members.length<490||members.length>550)throw problem('The provider returned an incomplete or unexpected S&P 500 member list.');
 const symbols=[...new Set(members.map(x=>String(x.symbol||'').toUpperCase()).filter(s=>/^[A-Z0-9][A-Z0-9.-]{0,14}$/.test(s)))];if(symbols.length!==members.length)throw problem('The index member list contains invalid or duplicate symbols. Ranking is paused.');const quotes=await batchedQuotes(symbols,key,fetchImpl),normalized=normalizeMembers(members,quotes,now);
 if(normalized.missing.length||normalized.ranked.length<490)throw problem('Cannot rank the full index: '+normalized.missing.length+' companies lack usable market capitalization. Ranking is paused rather than guessing the largest or smallest companies.');
 const oldestCap=Math.min(...normalized.ranked.map(x=>x.capAsOf));if(now-oldestCap>7*86400000)throw problem('The index capitalization snapshot is too old.');
 const value={ranked:normalized.ranked,membershipFetchedAt:now,marketCapAsOf:oldestCap,source:'Financial Modeling Prep S&P 500 constituents + batch quotes'};
 if(fetchImpl===fetch)snapshotCache={key,at:now,value};return value;
}
export async function forwardMarketFrame(state,{key='',now=Date.now(),fetchImpl=fetch,signalLimit=12}={}){
 const snapshot=await currentSp500({key,now,fetchImpl}),ranked=snapshot.ranked,provisional=selectUniverse(ranked,state.signals||{},state.config.middleCount??10),pool=middleCandidates(ranked);
 const instruments=new Map([...provisional.selected,...pool].map(x=>[x.symbol,x]));for(const [symbol,position] of Object.entries(state.positions||{}))if(position.heldUnits>0&&!instruments.has(symbol)){const old=state.instruments?.[symbol];if(old)instruments.set(symbol,{...old,cohort:'held',selectionReason:'Existing holding retained and monitored; not eligible for new buys unless selected again.'});}
 const rows=[...instruments.values()],rawQuotes=await batchedQuotes(rows.map(x=>x.symbol),key,fetchImpl),quotes=[];
 for(const q of rawQuotes){const price=Number(q.price),asOf=Number(q.timestamp)*1000;if(!instruments.has(q.symbol)||!Number.isFinite(price)||price<.01||!Number.isFinite(asOf)||asOf>now)continue;quotes.push({symbol:q.symbol,price,currency:'USD',asOf,volume:Number(q.volume)||0,source:'FMP current quote · freshness is checked before every paper fill'});}
 const start=state.signalCursor||0,signalRows=Array.from({length:Math.min(signalLimit,rows.length)},(_,i)=>rows[(start+i)%rows.length]);
 const publicFrame=await collectLiveFrame(signalRows.map(x=>x.symbol),{now,fetchImpl,instruments:signalRows,includeQuotes:false});
 return {...publicFrame,mode:'live',quotes,universe:{...snapshot,ranked:undefined,rankedCount:ranked.length,selected:provisional.selected,pool,selectionSymbols:provisional.selected.map(x=>x.symbol),instruments:rows,policy:provisional.policy},nextSignalCursor:(start+signalRows.length)%rows.length,sources:{...publicFrame.sources,quotes:quotes.length?'FMP responded':'No usable quote',index:snapshot.source},coverage:{priced:quotes.length,priceCandidates:rows.length,signalsScanned:signalRows.length,signalCandidates:rows.length},errors:[...publicFrame.errors,...(quotes.length<rows.length?['Some candidate quotes are missing; those companies cannot produce fills.']:[])]};
}
export async function initializeForwardSimulation(options={},provider={}){
 const count=Number(options.middleCount??10);if(!Number.isInteger(count)||count<0||count>20)throw problem('Middle company count must be an integer from 0 to 20.',400);
 const now=provider.now??Date.now(),snapshot=await currentSp500({...provider,now}),selection=selectUniverse(snapshot.ranked,{},Number(options.middleCount??10));
 const instruments=[...new Map([...selection.selected,...selection.pool].map(x=>[x.symbol,x])).values()];
 const universe={...snapshot,ranked:undefined,rankedCount:snapshot.ranked.length,selected:selection.selected,pool:selection.pool,selectionSymbols:selection.selected.map(x=>x.symbol),instruments,policy:selection.policy};
 return createSimulation({...options,mode:'live',strategy:'sp500-forward',universe,instruments,watchlist:instruments.map(x=>x.symbol)},now);
}
