module.exports=function createSimulatorService({db,json,body,fail,session,limit=()=>{},getFrame=null}){
db.exec(`CREATE TABLE IF NOT EXISTS simulations(user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,mode TEXT NOT NULL,state TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,mode));`);
const engine=import('../dist/simulator-engine.js'),provider=import('./sp500-data.mjs');let polling=false;
const intervalMs=Math.max(60000,Number(process.env.SIMULATOR_POLL_MS)||60000);
function load(userId,mode){return db.prepare('SELECT * FROM simulations WHERE user_id=? AND mode=?').get(userId,mode);}
function storeNew(userId,state,expected){const old=load(userId,state.mode);if(old&&old.revision!==expected||!old&&expected!==null&&expected!==undefined)fail(409,'Simulation changed while market data loaded. Refresh before replacing it.');db.prepare('INSERT INTO simulations VALUES(?,?,?,0) ON CONFLICT(user_id,mode) DO UPDATE SET state=excluded.state,revision=simulations.revision+1').run(userId,state.mode,JSON.stringify(state));return old?old.revision+1:0;}
function update(userId,state,revision){const r=db.prepare('UPDATE simulations SET state=?,revision=revision+1 WHERE user_id=? AND mode=? AND revision=?').run(JSON.stringify(state),userId,state.mode,revision);if(!r.changes)fail(409,'Simulation changed elsewhere. Refresh it before trying again.');return revision+1;}
async function poll(userId,row){const {ingestFrame}=await engine,{forwardMarketFrame}=await provider;const state=JSON.parse(row.state);if(!getFrame&&state.strategy!=='sp500-forward')fail(409,'Previous simulation preserved. Export its ledger, then create a new forward simulation.');const frame=await (getFrame?getFrame(state.watchlist):forwardMarketFrame(state,{key:process.env.FMP_API_KEY||''}));const next=ingestFrame(state,frame,Date.now());next.sources=frame.sources;const revision=update(userId,next,row.revision);return {state:next,revision,sources:frame.sources};}
async function tick(){if(polling)return;polling=true;try{for(const row of db.prepare("SELECT * FROM simulations WHERE mode='live'").all()){const state=JSON.parse(row.state);if(!getFrame&&state.strategy!=='sp500-forward')continue;if(!state.running||state.lastPollAt&&Date.now()-state.lastPollAt<intervalMs)continue;try{await poll(row.user_id,row);}catch(e){{const fresh=load(row.user_id,'live');if(fresh&&fresh.revision===row.revision){state.lastError=e.status===409?e.message:'Server update failed. No trade was filled by this failed update.';state.lastPollAt=Date.now();try{update(row.user_id,state,row.revision)}catch{}}}}}}finally{polling=false}}
const timer=setInterval(tick,60000);timer.unref();
return {tick,close:()=>clearInterval(timer),async handle(req,res,url){
 if(!url.pathname.startsWith('/api/simulator/'))return false;
 if(url.pathname==='/api/simulator/status'&&req.method==='GET'){json(res,200,{paperOnly:true,strategy:'sp500-forward',policy:{top:20,bottom:10,middle:10},priceKeyConfigured:!!process.env.FMP_API_KEY,worker:'server',intervalSeconds:intervalMs/1000,offComputerVerified:false,hostingNote:'This worker runs only while this server is online. A local server stops when its computer is off.',social:'Public Bluesky, subject to endpoint availability. Other networks are not connected.'});return true;}
 const user=session(req);if(!user)fail(401,'Sign in to create a forward paper simulation.');
 const mode=url.searchParams.get('mode')==='demo'?'demo':'live';
 if(url.pathname==='/api/simulator/state'&&req.method==='GET'){const row=load(user.id,mode);json(res,200,row?{state:JSON.parse(row.state),revision:row.revision}:{state:null,revision:null});return true;}
 if(req.method!=='POST')fail(405,'Method not allowed.');const input=await body(req,32768);
 if(url.pathname==='/api/simulator/reset'){
  limit('sim-reset:'+user.id,5,900000);const old=load(user.id,'live');if(old&&input.revision!==old.revision)fail(409,'Simulation changed elsewhere. Refresh before replacing it.');const {initializeForwardSimulation}=await provider;const state=await initializeForwardSimulation(input,{key:process.env.FMP_API_KEY||''});const revision=storeNew(user.id,state,input.revision);json(res,200,{state,revision});return true;
 }
 const row=load(user.id,'live');if(!row)fail(409,'Create a live-data simulation first.');if(input.revision!==row.revision)fail(409,'Simulation changed elsewhere. Refresh it first.');
 if(url.pathname==='/api/simulator/poll'){limit('sim-poll:'+user.id,15,900000);const current=JSON.parse(row.state);if(current.lastPollAt&&Date.now()-current.lastPollAt<60000)fail(429,'Wait at least one minute between source scans.');const result=await poll(user.id,row);json(res,200,result);return true;}
 if(url.pathname==='/api/simulator/control'){const state=JSON.parse(row.state);if(state.strategy!=='sp500-forward')fail(409,'Create a new forward simulation first.');state.running=input.running===true;const revision=update(user.id,state,row.revision);json(res,200,{state,revision});return true;}
 fail(404,'Unknown simulator action.');
}};
};
