# BetaTrade for Windows

Extract **all** of `BetaTrade-v4-Windows.zip` into one folder, then open `BetaTrade.exe`. Windows 10/11 x64 is required. Node is bundled; no separate Python or Node installation is needed to launch the application. Keep the accompanying DLL, resources and locale files next to the executable. This is an unsigned portable build.

**Web Desk** is a native Chromium browser view, with tabs, back/forward, reload, direct HTTPS address entry and ChatGPT/Gemini/Claude shortcuts. Enter `example.com` or an AI shortcut name. Arbitrary search phrases are not sent to Google. Remote sites use isolated storage and never receive the local application's desktop bridge. Site CSP, certificate validation and sandboxing remain enabled. Some providers may require the system browser for sign-in or unsupported features. **Open externally** is the explicit fallback. No external account is created automatically.

**Appearance** offers Dark, Light and System in all applications. BetaTrade retains #0372FD accents and a logo without a white rectangle.

**Market data** accepts your FMP key, stored encrypted through Windows. A plan with complete current index/cap/quote coverage is needed; free coverage is not guaranteed. No subscription is purchased by the app.

Application data lives in `%APPDATA%\BetaTrade`, with server account/database files under `server-data`. It stays on this Windows user account; another computer does not automatically synchronize it. Existing browser-edition IndexedDB data is separate: export project ZIPs from old Code Studio and import them here. Keep backups before updating. Closing the app stops its local simulator. Running with the computer off requires separately configured cloud hosting.

For source development, run `npm ci` and `npm start` inside `desktop/`. The bundled backend uses loopback port 17658. Do not run another application on that port.

Real market fills have not been verified without a provider key. Cloud operation is not activated. No broker or real-money order endpoint exists.
