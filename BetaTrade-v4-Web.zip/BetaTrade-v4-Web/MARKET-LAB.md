# Market Lab v4 — current observations, virtual funds

The customer UI uses forward observations only. It never downloads historical candles or substitutes fictional prices. Synthetic replay remains solely as an internal accounting test fixture.

## Current universe

FMP `stable/sp500-constituent` and `stable/batch-quote` supply membership, market caps and prices. Configure `FMP_API_KEY` privately on the server, or use Windows **Market data**. Entitlement for complete index membership, company caps and current quotes is required; free availability is not promised. The app never purchases a plan.

The complete list must have 490–550 securities and at least 490 companies after consolidating share classes by CIK. The most liquid available class represents each company; caps are not summed across classes. Missing company caps stop ranking. Cap snapshots refresh hourly and snapshots older than seven days are rejected. The UI shows timestamps.

The 20 largest and 10 smallest companies by cap are included. Ten middle companies are added by default (configurable 0–20) from forty stratified middle-rank candidates. Initial middle choices are provisional rank/sector samples. Post-start momentum, volatility, moving-average gap and distinct-source keyword sentiment refine them with sector diversification. Scores are heuristic, not calibrated probabilities or guaranteed predictions. Quotes cover all seventy candidates plus existing holdings. Only currently selected companies receive new buys; previous holdings remain monitored for sales.

## Forward decisions

Scans default to once per minute. Quotes must be no more than two minutes old, not future-dated. Warmup requires five distinct post-start observations spanning four minutes. Closed markets or delayed plans can prevent fills. The news/social scanner rotates over twelve candidates per scan; full coverage normally needs about six scans plus network/provider delay. There is no instantaneous-reaction guarantee.

Public Google News RSS supplies news. Bluesky search has an explicit Mastodon hashtag fallback. Availability and limited coverage are visible; X, Reddit, Facebook and Instagram are not connected. Only reports published after this simulation starts and within thirty minutes enter decisions. English keyword headlines are not independently fact-checked. Two distinct source identities, different texts and aligned price statistics are required for news/social-driven buys and sells. Statistical downward risk can also sell existing shares. No short positions are opened.

## Accounting and worker

Default balance: $10,000 virtual USD. Buys use 10% of initial capital, limited by cash and 30% per-company exposure. Sales target 25% of held shares, capped so at least 60% of **all acquired shares** remains. Repeated sales cannot bypass the cumulative floor. It protects quantity, not value. Each fill charges $0.50 and 5 basis points of slippage. Sale proceeds remain virtual cash. CSV exports include quote timestamps. Portfolio values use latest known prices; stale holdings are labeled and cannot fill trades. Tax figures are adjustable illustrative estimates.

Previous simulations are preserved, labeled, and excluded from v4 automatic execution. Export the old ledger before explicitly replacing it. A revision check prevents overwriting another client's change.

The Node server owns execution and can work with the tab closed. Windows closing or switching the computer off stops its server. **No external host or computer-off schedule has been activated.**

For cloud operation, configure Supabase auth/schema, cloud-config.js, and function secrets FMP_API_KEY, APP_ORIGIN and MARKET_WORKER_KEY. Deploy market-lab and verify authenticated state isolation/manual scans. Then configure Vault and apply the supplied one-minute cron SQL. Bounded invocations handle one due account at a time; larger installations need queue/quota planning. Verify a scheduled write/readback with all clients closed before claiming computer-off operation. Source files alone do not activate hosting.

Provider documentation: https://site.financialmodelingprep.com/developer/docs/stable/sp-500-constituent and https://site.financialmodelingprep.com/developer/docs/stable/batch-quote
