# Hosting BetaTrade without your own server

The website has two supported account backends. The default downloaded copy uses the included Node 24 server and SQLite. The managed cloud option uses Supabase Auth and Postgres, and serves the static frontend through Render or another static host.

## Managed cloud option

1. Create/connect your own Supabase project using its Free plan. No paid AI service is needed. Free plans have usage limits and inactive projects may pause.
2. Apply `cloud/schema.sql` once to a new Supabase project. Row Level Security separates account workspaces. The save function checks the revision to reject conflicting changes from another device.
3. Set `dist/cloud-config.js` to export `{url: 'https://PROJECT.supabase.co', publishableKey: 'PUBLISHABLE_KEY'}`. A public publishable/anon key belongs here. A secret/service_role key must never appear in these files.
4. Enable email/password sign-in in Supabase Auth. Keep email confirmation enabled. Configure Site URL and allowed redirect URLs to the final production HTTPS origin. The confirmation link returns to this site. Set a 12-character minimum password in Supabase as well. Review email delivery limits; custom SMTP is not configured by this package.
5. Deploy `dist` as a static website. `render.yaml` supplies a Render static-site definition when this folder is a repository root. This avoids running SQLite on an ephemeral free web-service disk.
6. Verify email signup, confirmation, sign-in, sign-out and project ownership with two real test accounts. Test a second browser/device and concurrent-save conflict. Supabase integration cannot be validated until connected to an actual project.

Static hosting without configured Supabase still renders the device workspace, but email/password sign-in requires either Supabase configuration or the included Node server.

## Node server alternative

Run `npm start` with Node 24+. Production requires HTTPS termination and these environment variables:

- `NODE_ENV=production`
- `APP_ORIGIN=https://your-public-hostname` (no trailing slash)
- `PORT` and optionally `HOST=0.0.0.0`
- `DATA_DIR` pointing to a persistent, writable directory

The supplied Dockerfile runs as an unprivileged user. Mount persistent storage at `/app/data`. Back up this directory; it contains user accounts, hashed passwords, sessions and account workspaces. Do not include it in a ZIP or public repository.

The local account server uses scrypt password hashing, HttpOnly SameSite cookies, secure production cookies, server-side authorization and origin checks, rate limits, and optimistic workspace revisions. It does not verify mailbox ownership or provide password-reset email. Do not claim those features are enabled. For online use, prefer the managed Supabase option above.

## AI and Python limits

AI inference and Python execution run on the visitor's device. This avoids paid inference servers but does not guarantee every device can run a model: WebGPU and sufficient GPU memory are required. Smaller models offer more limited coding quality. Native Python packages and server frameworks are not supported by the browser runner.

## Verified vs pending

Verified locally: registration, account workspace import, server authorization/isolation, session persistence, conflicting writes, Python execution, and the AI edit flow. Automated tests cover server authorization and replacement parsing.

Pending: connected Supabase project, real email confirmation, published hosting origin and cross-device verification against that origin. There is no verified public deployment URL yet.
