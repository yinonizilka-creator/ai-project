const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const derive=require('node:util').promisify(crypto.scrypt);
const {DatabaseSync}=require('node:sqlite');
const root=path.join(__dirname,'dist'),dataDir=path.resolve(process.env.DATA_DIR||path.join(__dirname,'data'));
fs.mkdirSync(dataDir,{recursive:true});
const db=new DatabaseSync(path.join(dataDir,'betatrade.sqlite'));
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,salt TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS workspaces(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,projects TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS rate_limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,reset_at INTEGER NOT NULL);`);
const production=process.env.NODE_ENV==='production',origin=process.env.APP_ORIGIN||'',port=Number(process.env.PORT)||8765;
if(production&&!/^https:\/\/[^/]+$/.test(origin))throw Error('Set APP_ORIGIN to the public HTTPS origin without a trailing slash.');
let hashing=0;
function json(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body));}
function fail(status,message){const e=Error(message);e.status=status;throw e;}
const digest=t=>crypto.createHash('sha256').update(t).digest('hex');
function token(req){return(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('bt_session='))?.slice(11);}
function session(req){const t=token(req);if(!t||!/^[a-f0-9]{64}$/.test(t))return null;return db.prepare('SELECT users.id,users.email FROM sessions JOIN users ON sessions.user_id=users.id WHERE token_hash=? AND expires_at>?').get(digest(t),Date.now());}
function cookie(res,t,age=604800){res.setHeader('Set-Cookie',`bt_session=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${production?'; Secure':''}`);}
function issue(res,user){const t=crypto.randomBytes(32).toString('hex');db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(digest(t),user.id,Date.now()+604800000);cookie(res,t);}
function limit(key,max,window){const now=Date.now();db.prepare('DELETE FROM rate_limits WHERE reset_at<?').run(now);const row=db.prepare('SELECT count FROM rate_limits WHERE key=?').get(key);if(row&&row.count>=max)fail(429,'Too many attempts. Try again later.');db.prepare('INSERT INTO rate_limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1').run(key,now+window);}
async function hash(password,salt){if(hashing>=2)fail(503,'Sign-in is busy. Try again shortly.');hashing++;try{return await derive(password,salt,64,{N:131072,r:8,p:1,maxmem:256*1024*1024});}finally{hashing--;}}
async function body(req,max=16*1024*1024){if(!String(req.headers['content-type']||'').startsWith('application/json'))fail(415,'Use JSON.');let size=0;const parts=[];for await(const c of req){size+=c.length;if(size>max)fail(413,'Workspace exceeds its size limit.');parts.push(c);}try{return JSON.parse(Buffer.concat(parts).toString('utf8'));}catch{fail(400,'Invalid JSON.');}}
function validate(projects){if(!Array.isArray(projects)||projects.length>100)fail(400,'Use up to 100 projects.');const ids=new Set();for(const p of projects){if(!p||typeof p.id!=='string'||!p.id||p.id.length>100||ids.has(p.id)||typeof p.name!=='string'||!p.name.trim()||p.name.length>200||typeof p.description!=='string'||p.description.length>500||!p.files||typeof p.files!=='object'||Array.isArray(p.files)||typeof p.entry!=='string')fail(400,'Invalid project.');ids.add(p.id);const names=Object.keys(p.files);if(names.length>500)fail(400,'Use up to 500 files per project.');for(const n of names){if(!n||n.length>300||n.startsWith('/')||n.includes('\\')||n.includes(':')||n.includes('\0')||n.split('/').includes('..')||typeof p.files[n]!=='string')fail(400,'Invalid project file.');}if(p.entry&&!names.includes(p.entry))fail(400,'Entry file is missing.');}}
const simulator=require('./services/simulator-service.cjs')({db,json,body,fail,session,limit});
const server=http.createServer(async(req,res)=>{
res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');
try{
const url=new URL(req.url,'http://localhost');
if(url.pathname==='/api/health')return json(res,200,{ok:true});
if(url.pathname.startsWith('/api/')){
if(!['GET','POST','PUT'].includes(req.method))fail(405,'Method not allowed.');
if(req.method!=='GET'&&(req.headers.origin!==(origin||`http://${req.headers.host}`)||req.headers['x-betatrade-request']!=='1'))fail(403,'Request origin rejected.');
if(await simulator.handle(req,res,url))return;
if(url.pathname==='/api/auth/me'&&req.method==='GET')return json(res,200,{user:session(req)});
if(['/api/auth/register','/api/auth/login'].includes(url.pathname)&&req.method==='POST'){
const ip=req.socket.remoteAddress||'unknown';limit('auth:'+ip,25,900000);const b=await body(req,4096),email=typeof b.email==='string'?b.email.trim().toLowerCase():'',password=b.password;
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||typeof password!=='string'||password.length<12||password.length>256)fail(400,'Enter a valid email and a password of 12–256 characters.');
const row=db.prepare('SELECT * FROM users WHERE email=?').get(email);
if(url.pathname.endsWith('register')){
limit('register:'+ip,5,3600000);const salt=crypto.randomBytes(32).toString('hex'),password_hash=(await hash(password,salt)).toString('hex');if(row)fail(409,'Unable to create this account. Try signing in.');
const user={id:crypto.randomUUID(),email};try{db.prepare('INSERT INTO users VALUES(?,?,?,?)').run(user.id,email,password_hash,salt);db.prepare('INSERT INTO workspaces VALUES(?,?,0)').run(user.id,'[]');}catch(e){if(e.code?.includes('CONSTRAINT'))fail(409,'Unable to create this account. Try signing in.');throw e;}issue(res,user);return json(res,201,{user});
}
const check=await hash(password,row?.salt||'00'.repeat(32));if(!row||!crypto.timingSafeEqual(check,Buffer.from(row.password_hash,'hex')))fail(401,'Email or password is incorrect.');issue(res,row);return json(res,200,{user:{id:row.id,email:row.email}});
}
const user=session(req);if(!user)fail(401,'Please sign in.');
if(url.pathname==='/api/auth/logout'&&req.method==='POST'){const t=token(req);if(t)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(digest(t));cookie(res,'',0);return json(res,200,{ok:true});}
if(url.pathname==='/api/projects'&&req.method==='GET'){const r=db.prepare('SELECT projects,revision FROM workspaces WHERE user_id=?').get(user.id);return json(res,200,{projects:JSON.parse(r.projects),revision:r.revision});}
if(url.pathname==='/api/projects'&&req.method==='PUT'){const b=await body(req);validate(b.projects);if(!Number.isSafeInteger(b.revision)||b.revision<0)fail(400,'Missing workspace revision.');const r=db.prepare('UPDATE workspaces SET projects=?,revision=revision+1 WHERE user_id=? AND revision=?').run(JSON.stringify(b.projects),user.id,b.revision);if(!r.changes)fail(409,'Workspace changed on another device. Export local changes, then reload.');return json(res,200,{revision:b.revision+1});}
fail(404,'Not found.');
}
if(!['GET','HEAD'].includes(req.method))fail(405,'Method not allowed.');let requested;try{requested=decodeURIComponent(url.pathname);}catch{fail(400,'Invalid path.');}
const file=path.resolve(root,'.'+(requested==='/'?'/index.html':requested));if(!file.startsWith(root+path.sep))fail(403,'Forbidden.');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.json':'application/json; charset=utf-8'};
fs.readFile(file,(err,data)=>{res.writeHead(err?404:200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(req.method==='HEAD'?'':err?'Not found':data);});
}catch(e){json(res,e.status||500,{error:e.status?e.message:'Something went wrong. Try again.'});if(!e.status)console.error('Request failed:',e.code||e.name);}
});
server.requestTimeout=120000;server.headersTimeout=15000;
server.listen(port,process.env.HOST||(production?'0.0.0.0':'127.0.0.1'),()=>console.log(`BetaTrade is ready: http://localhost:${port} — close this window to stop.`));
function shutdown(){simulator.close();server.close(()=>{db.close();process.exit(0);});}process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
