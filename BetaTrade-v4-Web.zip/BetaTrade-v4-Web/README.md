# BetaTrade 4.0

The opening screen now provides access to **Code Studio** (the existing Python workspace), **Market Lab** (paper-only simulation) and **Web Desk** (native browser in Windows; permitted previews on the web). Add application shortcuts from the opening screen; shortcuts are stored on this device. The opening screen is static at this stage, without an intro animation.

Market Lab defaults to 10,000 virtual USD and preserves at least 60% of each holding's acquired shares across repeated sales. The customer screen uses post-start current observations only, and records fills, cash, fees and P&L. It can collect public news and available public social posts; a configured price provider is required for observed-data paper fills. Read `MARKET-LAB.md` for the complete rules and cloud-worker deployment/verification steps. **Computer-off operation is not activated in the downloaded local copy.**

The Windows edition includes a real Chromium browser with tabs and direct navigation plus ChatGPT, Gemini and Claude shortcuts. The website edition retains previews where sites permit embedding. All pages offer Dark, Light and System appearance. Read WINDOWS.md for installation and platform limits.

An English-language Python workspace with a charcoal interface inspired by ChatGPT, transparent native branding, email/password accounts, account project storage, and a free local coding assistant that can propose and apply full-file edits.

## Portable Windows edition

Extract BetaTrade-v4-Windows.zip completely and open BetaTrade.exe. No separate Node installation is needed. Existing browser storage is separate; export/import project ZIPs to transfer them.

## Website / source edition

1. Close the previous BetaTrade server window.
2. Extract the entire ZIP into a folder. Do not run from inside the ZIP.
3. Double-click `Start.cmd`. Requires Node.js 24 or newer (already available on the computer used to build this site).
4. Open http://localhost:8765 and keep the server window open. The opening screen appears first; choose Code Studio to reach the existing application. Preserve/copy your previous `data` folder when upgrading so local accounts and account projects remain available. Device-side projects/attachments remain on their original browser origin.

The **Sign in** button creates/opens an account. Passwords must be 12–256 characters. This local server identifies users by email but does not verify email ownership or send password-reset mail. Keep your password safe. Local account data is in the `data` folder; back it up and preserve it when updating the application.

Device projects migrate from previous browser storage into IndexedDB on the same origin. After signing in, use the account menu's **Import device projects** button to copy source files and attachment references into your account. Account projects are separate from device projects.

## Large project imports

Select all project files together, including `.pth`, `.pt`, large text datasets and binary data, or import a ZIP. Limits are 256 MB per file and 512 MB per project, with up to 500 files. Source text up to 1 MB per file is editable, with a 4 MB total source budget. Larger text files and binary files are stored intact as device attachments in IndexedDB. Large text has a read-only preview. Binary weights are never decoded as text.

**Attachments remain on the importing device. They do not sync to account/cloud storage.** On another computer, re-import the original files. Export ZIP includes source files and complete attachments. Browser storage capacity, memory and available disk space still apply. Clearing this site's browser data deletes device attachments; keep ZIP backups.

Imports and execution are separate. Ordinary scripts can access imported binary/text attachments through the browser filesystem. Projects importing PyTorch, TensorFlow, desktop GUI libraries or Python server frameworks require a regular Python environment; the app explains this rather than claiming they can run in the browser. The presence of a `.pth` file alone does not identify the original project's exact dependencies.

## AI edits

The assistant defaults to the Balanced Qwen2.5-Coder 1.5B model. Fast 0.5B and Stronger 3B options are available. Models run locally through WebLLM and require WebGPU, internet for the first download, and sufficient GPU memory. There is no paid AI API or key. Larger models require larger downloads; coding quality remains more limited than large hosted AI services.

Open a Python file, load a model, describe a change and click **Edit file**. Review the complete replacement, choose **Apply to editor**, then run the project to test it. **Undo last AI edit** restores the previous content unless you have edited it since. Changes are never applied automatically. Edits to a file that changed during generation are rejected.

Python executes in a worker through Pyodide. The first run downloads Python. Compatible packages work; native OS dependencies, interactive input(), Python web servers and background services require another runtime. Runtime file changes are temporary and are not copied back into the source editor.

## Use from different computers

An online hosting origin is required. The downloaded local copy does not become an online website by itself. `DEPLOYMENT.md` describes the prepared managed option: Supabase for email/password authentication and durable project storage, plus static hosting such as Render. Supabase and Render account connections and a production deployment have not been completed. No live URL is verified yet.

The optional local Node backend includes persistent SQLite storage, hashed passwords, protected sessions, user-owned workspaces and conflicting-write detection. Hosting this backend requires a persistent disk and HTTPS. Do not deploy SQLite to an ephemeral free web-service disk.

## Checks

Run `npm test` with Node 24+. Tests cover authentication, authorization, account isolation, session persistence, request-origin checks, revision conflicts and code-replacement parsing. Browser checks verify registration, project import, local model loading, applying an AI edit and undoing it. Managed cloud integration needs live verification after account connection.
