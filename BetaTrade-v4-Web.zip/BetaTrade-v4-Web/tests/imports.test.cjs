const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../dist/project-files.js'),'utf8');
const modulePromise=import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
test('a 129 MB model and 27 MB dataset are kept as binary-safe attachments',async()=>{
const {collectProject}=await modulePromise;const saved=new Map();
// Lightweight file stubs prove the importer never decodes model/data files as text.
const model={name:'my_ai_model.pth',size:131845*1024,type:'application/octet-stream',text:()=>{throw Error('Model must not be decoded')}};
const input={name:'input.txt',size:28106*1024,type:'text/plain',text:()=>{throw Error('Large dataset must not be decoded')}};
const code=new File(['print("ready")'],'app_chat.py',{type:'text/plain'});
const p=await collectProject([code,input,model],{storeAsset:async(id,blob)=>saved.set(id,blob)});
assert.equal(p.files['app_chat.py'],'print("ready")');assert.equal(p.entry,'app_chat.py');assert.equal(Object.keys(p.assets).length,2);assert.equal(p.assets['my_ai_model.pth'].size,model.size);assert.equal(p.assets['input.txt'].text,true);assert.equal(saved.get(p.assets['my_ai_model.pth'].id),model);assert.ok(p.total>150*1024*1024);
});
test('binary bytes survive storage and import without text conversion',async()=>{
const {collectProject}=await modulePromise,stored=new Map();const bytes=new Uint8Array([0,255,128,80,75,3,4]);
const p=await collectProject([new File(['print(1)'],'main.py'),new File([bytes],'model.pth')],{storeAsset:async(id,blob)=>stored.set(id,blob)});
assert.deepEqual(new Uint8Array(await stored.get(p.assets['model.pth'].id).arrayBuffer()),bytes);
});
test('limits, duplicate names, archive traversal and runtime compatibility are explicit',async()=>{
const {checkImportSize,MAX_FILE,MAX_PROJECT,collectProject,runtimeIssue}=await modulePromise;
assert.throws(()=>checkImportSize('model.pth',MAX_FILE+1,MAX_FILE+1),/256 MB/);assert.throws(()=>checkImportSize('data.txt',1,MAX_PROJECT+1),/512 MB/);assert.throws(()=>checkImportSize('../secret.py',1,1),/path/);
await assert.rejects(collectProject([new File(['a'],'main.py'),new File(['b'],'main.py')]),/same path/);
await assert.rejects(collectProject([new File(['x'],'x.zip')],{unzip:async(_bytes,filter)=>{filter({name:'../bad.py',originalSize:3});return {}}}),/path/);
assert.equal(runtimeIssue({'chat.py':'import torch\nprint(1)'}).package,'torch');assert.equal(runtimeIssue({'gui.py':'from tkinter import Tk'}).package,'tkinter');assert.equal(runtimeIssue({'main.py':'print("torch")'}),null);
});
