const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..');
const engine=import('../dist/simulator-engine.js');
test('cumulative repeated sales preserve at least 60% of ALL acquired shares',async()=>{
 const {createSimulation,executePaperTrade}=await engine;const s=createSimulation({mode:'live'},1000);s.quotes.SPCX={priceCents:10000,asOf:1000,source:'test'};
 assert.ok(executePaperTrade(s,'SPCX','BUY',1000).ok);const acquired=s.positions.SPCX.acquiredUnits;
 for(let i=0;i<100;i++){executePaperTrade(s,'SPCX','SELL',1001+i);assert.ok(s.positions.SPCX.heldUnits>=Math.ceil(acquired*.6));assert.ok(s.cashCents>=0)}
 assert.equal(s.positions.SPCX.heldUnits,Math.ceil(acquired*.6));assert.match(executePaperTrade(s,'SPCX','SELL',1200).reason,/60%/);
 // A new acquisition increases the protected baseline instead of resetting sold shares.
 executePaperTrade(s,'SPCX','BUY',1300);const next=s.positions.SPCX.acquiredUnits;for(let i=0;i<20;i++)executePaperTrade(s,'SPCX','SELL',1400+i);assert.ok(s.positions.SPCX.heldUnits>=Math.ceil(next*.6));
});
test('cash stays in the simulator; fees, slippage, realized P&L and illustrative tax reconcile',async()=>{
 const {createSimulation,executePaperTrade,summary}=await engine;const s=createSimulation({},1000);s.quotes.SPCX={priceCents:10000,asOf:1000,source:'test'};const buy=executePaperTrade(s,'SPCX','BUY',1000).trade;assert.ok(buy.priceCents>10000);assert.equal(s.cashCents,s.initialCents+buy.cashChangeCents);assert.ok(summary(s).pnlCents<0);
 s.quotes.SPCX={priceCents:12000,asOf:2000,source:'test'};const before=s.cashCents,sell=executePaperTrade(s,'SPCX','SELL',2000).trade;assert.ok(sell.priceCents<12000);assert.equal(s.cashCents,before+sell.cashChangeCents);const totals=summary(s);assert.equal(totals.pnlCents,totals.realizedCents+totals.unrealizedCents);assert.equal(totals.taxEstimateCents,Math.round(s.realizedCents*.25));assert.equal(totals.equityCents,s.cashCents+totals.holdingsCents);assert.equal(s.feesCents,100);
});
function reports(at){return [{id:'a',symbol:'SPCX',title:'SpaceX announces a new launch',publishedAt:at,url:'https://publisher-one.example/a',channel:'news'},{id:'b',symbol:'SPCX',title:'SpaceX wins contract after approval',publishedAt:at,url:'https://publisher-two.example/b',channel:'news'}]}
test('no lookahead, duplicate fills, stale fills, single-source fills or cross-mode mixing',async()=>{
 const {createSimulation,ingestFrame}=await engine,t=1000000;let s=createSimulation({mode:'live'},t);
 const q={symbol:'SPCX',price:100,currency:'USD',asOf:t,source:'test'};
 s=ingestFrame(s,{mode:'live',quotes:[q],events:reports(t).slice(0,1)},t);assert.equal(s.trades.length,0);
 s=ingestFrame(s,{mode:'live',quotes:[q],events:reports(t)},t);assert.equal(s.trades.length,1);
 s=ingestFrame(s,{mode:'live',quotes:[q],events:reports(t)},t+1);assert.equal(s.trades.length,1);
 assert.throws(()=>ingestFrame(s,{mode:'demo',events:[],quotes:[]},t),/cannot be mixed/);
 for(const quote of [{...q,asOf:t+1},{...q,asOf:t-20*60000},{...q,currency:'KRW'},{...q,price:NaN}]){const fresh=ingestFrame(createSimulation({mode:'live'},t),{mode:'live',quotes:[quote],events:reports(t)},t);assert.equal(fresh.trades.length,0)}
 const oldEvents=ingestFrame(createSimulation({mode:'live'},t),{mode:'live',quotes:[q],events:reports(t-1)},t);assert.equal(oldEvents.trades.length,0);
});
test('copied headlines and one social account do not count as independent confirmation',async()=>{
 const {createSimulation,ingestFrame}=await engine,t=1000000,q={symbol:'SPCX',price:100,currency:'USD',asOf:t};
 let events=reports(t);events[1].title=events[0].title;let s=ingestFrame(createSimulation({mode:'live'},t),{mode:'live',quotes:[q],events},t);assert.equal(s.trades.length,0);
 events=reports(t).map(e=>({...e,channel:'social',authorId:'same-account'}));s=ingestFrame(createSimulation({mode:'live'},t),{mode:'live',quotes:[q],events},t);assert.equal(s.trades.length,0);
});
test('demo is deterministic, allows losses, and labels every price synthetic',async()=>{
 const {createSimulation,ingestFrame,demoFrames,summary}=await engine;let s=createSimulation({mode:'demo'},1000);for(const frame of demoFrames(1000))s=ingestFrame(s,frame,frame.at);assert.ok(s.trades.length>0);assert.ok(summary(s).pnlCents<0);for(const q of Object.values(s.quotes))assert.match(q.source,/Synthetic/);for(const p of Object.values(s.positions))assert.ok(p.heldUnits>=Math.ceil(p.acquiredUnits*.6));
 assert.throws(()=>createSimulation({budgetDollars:-1}),/budget/);
});
test('real-data adapters preserve publication times and do not invent missing prices',async()=>{
 const {collectLiveFrame,parseNewsRss}=await import('../services/market-data.mjs');const xml='<rss><channel><item><title><![CDATA[SpaceX announces a launch]]></title><link>https://news.example/article</link><guid>a</guid><pubDate>Mon, 02 Nov 2026 08:00:00 GMT</pubDate><source url="https://publisher.example">Publisher</source></item></channel></rss>';
 const posts={posts:[{uri:'at://did:plc:test/app.bsky.feed.post/abc',author:{did:'did:plc:test'},record:{text:'SpaceX successful launch',createdAt:'2026-11-02T08:00:00Z'}}]};
 const frame=await collectLiveFrame(['SPCX'],{key:'',fetchImpl:async url=>({ok:true,text:async()=>url.includes('news.google')?xml:JSON.stringify(posts)})});assert.equal(frame.events.length,2);assert.equal(frame.quotes.length,0);assert.match(frame.errors.join(' '),/No price provider key/);assert.equal(parseNewsRss(xml,'SPCX')[0].publisherUrl,'https://publisher.example');
});
test('server worker updates persisted simulations without an open browser',async t=>{
 const {DatabaseSync}=require('node:sqlite'),db=new DatabaseSync(':memory:');db.exec('CREATE TABLE users(id TEXT PRIMARY KEY); INSERT INTO users VALUES(\'test-user\');');
 const {createSimulation}=await engine;const started=Date.now(),state=createSimulation({mode:'live'},started);state.running=true;
 const factory=require('../services/simulator-service.cjs');const service=factory({db,json:()=>{},body:async()=>({}),fail:(status,message)=>{throw Object.assign(Error(message),{status})},session:()=>null,getFrame:async()=>({mode:'live',quotes:[{symbol:'SPCX',price:100,currency:'USD',asOf:Date.now(),source:'test'}],events:reports(started),sources:{news:'test'},errors:[]})});
 t.after(()=>{service.close();db.close()});db.prepare('INSERT INTO simulations VALUES(?,?,?,0)').run('test-user','live',JSON.stringify(state));await service.tick();const row=db.prepare('SELECT * FROM simulations').get(),saved=JSON.parse(row.state);assert.equal(row.revision,1);assert.equal(saved.trades.length,1);assert.ok(saved.lastPollAt>=started);
});
test('cloud worker ships the same paper accounting engine as the browser/server',()=>{assert.equal(fs.readFileSync(path.join(root,'dist/simulator-engine.js'),'utf8'),fs.readFileSync(path.join(root,'cloud/functions/_shared/simulator-engine.js'),'utf8'))});
test('deduplication fingerprints long identifiers and migrates older raw keys',async()=>{
 const {createSimulation,ingestFrame}=await engine,t=1000000;const rawId='rss:'+('long-id-'.repeat(500));const s=createSimulation({mode:'live'},t);s.processed=[rawId];
 const result=ingestFrame(s,{mode:'live',quotes:[],events:[{id:rawId,symbol:'SPCX',title:'SpaceX announces a launch',publishedAt:t}]},t);
 assert.equal(result.events.length,0);assert.equal(result.processed.length,1);assert.equal(result.processed[0].length,18);
});
test('social fallback is explicit and filters generic or unrelated hashtag posts',async()=>{
 const {collectLiveFrame}=await import('../services/market-data.mjs');
 const posts=[{id:'1',visibility:'public',account:{url:'https://social.example/@fruit'},created_at:new Date().toISOString(),url:'https://social.example/1',content:'<p>Sweet apples #apple</p>'},{id:'2',visibility:'public',account:{url:'https://social.example/@phone'},created_at:new Date().toISOString(),url:'https://social.example/2',content:'<p>iPhone users report overheating complaints</p>'}];
 const result=await collectLiveFrame(['AAPL'],{fetchImpl:async url=>url.includes('public.api.bsky')?{ok:false,status:403}:{ok:true,text:async()=>url.includes('news.google')?'<rss/>':JSON.stringify(posts)}});
 assert.equal(result.sources.social,'Mastodon public hashtag');assert.equal(result.events.length,1);assert.match(result.events[0].title,/iPhone/);assert.equal(result.quotes.length,0);
});
