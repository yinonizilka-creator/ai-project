const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const net=require('node:net');
const {once}=require('node:events');
test('accounts isolate projects, reject forged writes, detect conflicts and persist sessions',async t=>{
const probe=net.createServer();probe.listen(0,'127.0.0.1');await once(probe,'listening');const port=probe.address().port;await new Promise(r=>probe.close(r));
const data=fs.mkdtempSync(path.join(os.tmpdir(),'betatrade-test-'));const origin='http://127.0.0.1:'+port;let child;
async function start(){child=spawn(process.execPath,[path.join(__dirname,'../server.cjs')],{env:{...process.env,NODE_ENV:'test',PORT:String(port),DATA_DIR:data},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Server startup timed out')),10000);child.stdout.on('data',d=>{if(d.toString().includes('is ready')){clearTimeout(timer);resolve()}});child.on('exit',code=>{clearTimeout(timer);reject(Error('Server exited '+code))})});}
async function stop(){const p=child;child=null;if(p){p.kill();await once(p,'exit')}}
t.after(async()=>{await stop();fs.rmSync(data,{recursive:true,force:true})});await start();
async function call(route,method='GET',body,cookie,extra={}){const r=await fetch(origin+route,{method,headers:{...(method==='GET'?{}:{'Content-Type':'application/json',Origin:origin,'X-BetaTrade-Request':'1'}),...(cookie?{Cookie:cookie}:{}),...extra},body:body===undefined?undefined:JSON.stringify(body)});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0],rawCookie:r.headers.get('set-cookie')}}
assert.equal((await call('/api/projects')).status,401);
assert.equal((await call('/api/simulator/state')).status,401);
assert.equal((await call('/api/simulator/status')).data.paperOnly,true);
assert.equal((await call('/api/auth/register','POST',{email:'bad',password:'short'})).status,400);
assert.equal((await call('/api/auth/register','POST',{email:'a@example.test',password:'a long test password' },null,{Origin:'https://attacker.example'})).status,403);
const a=await call('/api/auth/register','POST',{email:'a@example.test',password:'a long test password'});assert.equal(a.status,201);assert.match(a.rawCookie,/HttpOnly/);assert.match(a.rawCookie,/SameSite=Strict/);
const b=await call('/api/auth/register','POST',{email:'b@example.test',password:'another test password'});assert.equal(b.status,201);
const sim=await call('/api/simulator/reset','POST',{budgetDollars:10000},a.cookie);assert.equal(sim.status,409);assert.match(sim.data.error,/market-data key/);
assert.equal((await call('/api/simulator/state','GET',undefined,b.cookie)).data.state,null);
const projects=[{id:'test-project',name:'Private A',description:'test',files:{'main.py':'print(42)'},entry:'main.py'}];
assert.equal((await call('/api/projects','PUT',{projects,revision:0},a.cookie)).data.revision,1);
assert.deepEqual((await call('/api/projects','GET',undefined,b.cookie)).data.projects,[]);
assert.deepEqual((await call('/api/projects','GET',undefined,a.cookie)).data.projects,projects);
assert.equal((await call('/api/projects','PUT',{projects:[],revision:0},a.cookie)).status,409);
assert.equal((await call('/api/projects','PUT',{projects:[{...projects[0],files:{'../escape.py':'bad'},entry:'../escape.py'}],revision:1},a.cookie)).status,400);
assert.equal((await call('/api/auth/login','POST',{email:'a@example.test',password:'incorrect long password'})).status,401);
const login=await call('/api/auth/login','POST',{email:'A@EXAMPLE.TEST',password:'a long test password'});assert.equal(login.status,200);
await stop();await start();assert.equal((await call('/api/auth/me','GET',undefined,a.cookie)).data.user.email,'a@example.test');assert.deepEqual((await call('/api/projects','GET',undefined,a.cookie)).data.projects,projects);
assert.equal((await call('/api/auth/logout','POST',{},a.cookie)).status,200);assert.equal((await call('/api/projects','GET',undefined,a.cookie)).status,401);
});
test('AI edits require a complete fenced replacement file',async()=>{
const src=fs.readFileSync(path.join(__dirname,'../dist/assistant.js'),'utf8');const {parseCodeReply}=await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));
assert.equal(parseCodeReply('```python\nprint(42)\n```'),'print(42)\n');assert.throws(()=>parseCodeReply('print(42)'));assert.throws(()=>parseCodeReply('```python\n# rest of the code unchanged\n```'));assert.throws(()=>parseCodeReply('```python\na=1\n```\n```python\na=2\n```'));
});
