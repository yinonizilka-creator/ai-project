-- Run once in your own Supabase project. Browser access uses RLS, never service_role.
create table public.workspaces (
  user_id uuid primary key references auth.users(id) on delete cascade,
  projects jsonb not null default '[]'::jsonb,
  revision integer not null default 0 check (revision >= 0),
  constraint project_array check (jsonb_typeof(projects) = 'array'),
  constraint project_count check (jsonb_array_length(projects) <= 100),
  constraint workspace_size check (octet_length(projects::text) <= 16777216)
);
alter table public.workspaces enable row level security;
revoke all on public.workspaces from anon;
revoke all on public.workspaces from public;
grant select, insert, update on public.workspaces to authenticated;
create policy own_workspace_select on public.workspaces for select to authenticated using ((select auth.uid())=user_id);
create policy own_workspace_insert on public.workspaces for insert to authenticated with check ((select auth.uid())=user_id);
create policy own_workspace_update on public.workspaces for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create function public.save_workspace(expected_revision integer,next_projects jsonb)
returns integer language plpgsql security invoker set search_path='' as $$
declare new_revision integer;
begin
  if auth.uid() is null then raise exception 'Please sign in' using errcode='42501'; end if;
  if expected_revision < 0 or expected_revision is null then raise exception 'Invalid revision'; end if;
  update public.workspaces set projects=next_projects,revision=revision+1
  where user_id=auth.uid() and revision=expected_revision
  returning revision into new_revision;
  if not found then raise exception 'Workspace changed on another device. Export local changes, then reload.' using errcode='40001'; end if;
  return new_revision;
end;
$$;
revoke all on function public.save_workspace(integer,jsonb) from public,anon;
grant execute on function public.save_workspace(integer,jsonb) to authenticated;
