-- Account-owned live-data paper simulations. Demo replay stays on the device.
create table public.simulations (
 user_id uuid not null references auth.users(id) on delete cascade,
 mode text not null default 'live' check (mode='live'),
 state jsonb not null,
 revision integer not null default 0 check (revision>=0),
 running boolean not null default false,
 next_run_at timestamptz not null default now(),
 primary key(user_id,mode),
 constraint simulation_size check (octet_length(state::text)<=4194304)
);
alter table public.simulations enable row level security;
revoke all on public.simulations from public,anon,authenticated;
grant select on public.simulations to authenticated;
grant all on public.simulations to service_role;
create policy own_simulation_read on public.simulations for select to authenticated using ((select auth.uid())=user_id);
-- Writes run only in the authenticated Edge Function and always filter user_id.
create index simulation_due_idx on public.simulations(running,next_run_at);
