import {createClient} from 'https://esm.sh/@supabase/supabase-js@2.57.4';
import {createSimulation,ingestFrame} from '../_shared/simulator-engine.js';
import {forwardMarketFrame,initializeForwardSimulation} from '../_shared/sp500-data.mjs';
const url=Deno.env.get('SUPABASE_URL')||'',secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')||'';
const admin=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false}});
const allowedOrigin=Deno.env.get('APP_ORIGIN')||'';
function error(status:number,message:string):never{const e=new Error(message) as Error&{status:number};e.status=status;throw e;}
function check(result:any){if(result.error)error(500,'Simulation storage failed.');return result.data;}
async function record(userId:string){return check(await admin.from('simulations').select('*').eq('user_id',userId).eq('mode','live').maybeSingle());}
async function update(row:any,state:any){
 const rows=check(await admin.from('simulations').update({state,revision:row.revision+1,running:state.running,next_run_at:new Date(Date.now()+60000).toISOString()}).eq('user_id',row.user_id).eq('mode','live').eq('revision',row.revision).select('revision'));
 if(!rows?.length)error(409,'Simulation changed elsewhere. Refresh it before trying again.');return rows[0].revision;
}
async function poll(row:any,worker=false){
 if(row.state.strategy!=='sp500-forward')error(409,'Previous simulation preserved. Create a new forward simulation.');const frame=await forwardMarketFrame(row.state,{key:Deno.env.get('FMP_API_KEY')||''});
 const state=ingestFrame(row.state,frame,Date.now());state.sources=frame.sources;if(worker)state.workerRunAt=Date.now();
 const revision=await update(row,state);return {state,revision,sources:frame.sources};
}
async function workerAuthorized(value:string){const expected=Deno.env.get('MARKET_WORKER_KEY');if(!expected||!value)return false;const encoder=new TextEncoder();const [a,b]=await Promise.all([value,expected].map(x=>crypto.subtle.digest('SHA-256',encoder.encode(x))));const aa=new Uint8Array(a),bb=new Uint8Array(b);let diff=0;for(let i=0;i<aa.length;i++)diff|=aa[i]^bb[i];return diff===0;}
Deno.serve(async(req:Request)=>{
 const cors={'Access-Control-Allow-Origin':allowedOrigin,'Access-Control-Allow-Headers':'authorization, apikey, x-client-info, content-type, x-market-worker-key','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
 const json=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json','Cache-Control':'no-store'}});
 if(req.method==='OPTIONS'){if(!allowedOrigin||req.headers.get('origin')!==allowedOrigin)return json({error:'Origin rejected'},403);return new Response(null,{status:204,headers:cors});}
 try{
  if(req.method!=='POST')error(405,'Use POST.');
  const origin=req.headers.get('origin');if(origin&&origin!==allowedOrigin)error(403,'Origin rejected.');
  const raw=await req.text();if(raw.length>32768)error(413,'Request is too large.');const input=JSON.parse(raw);const action=input.action;
  if(action==='cron'){
   if(!await workerAuthorized(req.headers.get('x-market-worker-key')||''))error(401,'Worker authentication required.');
   // Bounded batches keep each invocation within hosted-runtime limits.
   const rows=check(await admin.from('simulations').select('*').eq('running',true).lte('next_run_at',new Date().toISOString()).order('next_run_at').limit(1));
   const outcomes=[];for(const row of rows||[]){try{await poll(row,true);outcomes.push({updated:true})}catch(e){outcomes.push({updated:false,status:(e as any).status||500});}}
   return json({paperOnly:true,checked:outcomes.length,outcomes});
  }
  if(action==='status')return json({paperOnly:true,worker:'cloud',intervalSeconds:60,priceKeyConfigured:!!Deno.env.get('FMP_API_KEY'),offComputerVerified:false,hostingNote:'Cloud deployment and a successful scheduled write/readback must be verified. A configured function alone does not prove the schedule works.'});
  const token=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'');if(!token)error(401,'Please sign in.');
  const identity=await admin.auth.getUser(token);if(identity.error||!identity.data.user)error(401,'Please sign in.');const userId=identity.data.user.id;
  const row=await record(userId);
  if(action==='state')return json(row?{state:row.state,revision:row.revision}:{state:null,revision:null});
  if(action==='reset'){
   if(row&&input.revision!==row.revision)error(409,'Simulation changed elsewhere. Refresh before replacing it.');const state=await initializeForwardSimulation(input,{key:Deno.env.get('FMP_API_KEY')||''});
   if(row){const revision=await update(row,state);return json({state,revision});}
   check(await admin.from('simulations').insert({user_id:userId,mode:'live',state,revision:0,running:false}));return json({state,revision:0});
  }
  if(!row)error(409,'Create a simulation first.');if(input.revision!==row.revision)error(409,'Simulation changed elsewhere. Refresh first.');
  if(action==='control'){if(row.state.strategy!=='sp500-forward')error(409,'Create a new forward simulation first.');const state={...row.state,running:input.running===true};const revision=await update(row,state);return json({state,revision});}
  if(action==='poll'){if(row.state.lastPollAt&&Date.now()-row.state.lastPollAt<60000)error(429,'Wait at least one minute between source scans.');return json(await poll(row));}
  error(404,'Unknown action.');
 }catch(e){const status=(e as any).status||500;return json({error:status===500?'Simulation request failed. No real trading is connected.':(e as Error).message,status},status);}
});
