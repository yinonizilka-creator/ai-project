import {marketStatistics,refreshUniverseSelection} from './market-strategy.js';
// Paper-only accounting. This module has no brokerage or payment integration.
export const INSTRUMENTS=[
 {symbol:'SPCX',name:'SpaceX',query:'SpaceX',currency:'USD',quoteSymbol:'SPCX'},
 {symbol:'AAPL',name:'Apple',query:'Apple iPhone',currency:'USD',quoteSymbol:'AAPL'},
 {symbol:'MSFT',name:'Microsoft',query:'Microsoft',currency:'USD',quoteSymbol:'MSFT'},
 {symbol:'TSLA',name:'Tesla',query:'Tesla',currency:'USD',quoteSymbol:'TSLA'},
 {symbol:'SAMSUNG',name:'Samsung Electronics',query:'Samsung Galaxy',currency:'KRW',quoteSymbol:null}
];
const SCALE=1000000n;
const round=value=>Math.round(value);
function assert(value,message){if(!value)throw Error(message)}
function eventKey(value){const text=String(value);if(/^h:[a-f0-9]{16}$/.test(text))return text;let a=2166136261,b=2654435769;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);a=Math.imul(a^c,16777619)>>>0;b=Math.imul(b^c,2246822519)>>>0;}return 'h:'+a.toString(16).padStart(8,'0')+b.toString(16).padStart(8,'0')}
export function createSimulation(options={},now=Date.now()){
 const budget=Number(options.budgetDollars??10000),percent=Number(options.taxPercent??25),tradePercent=Number(options.tradePercent??10);
 assert(Number.isFinite(budget)&&budget>=100&&budget<=1000000,'Starting budget must be $100–$1,000,000.');
 assert(Number.isFinite(percent)&&percent>=0&&percent<=60,'Illustrative tax rate must be 0–60%.');
 assert(Number.isFinite(tradePercent)&&tradePercent>=1&&tradePercent<=20,'Trade size must be 1–20% of the starting budget.');
 const mode=options.mode==='demo'?'demo':'live';
 const dynamic=options.strategy==='sp500-forward';const catalog=dynamic?options.instruments:INSTRUMENTS;if(!Array.isArray(catalog)||!catalog.length)throw Error('A verified current S&P 500 universe is required.');
 const watchlist=(options.watchlist||['SPCX','AAPL','SAMSUNG']).filter((s,i,a)=>catalog.some(x=>x.symbol===s)&&a.indexOf(s)===i).slice(0,dynamic?150:5);
 assert(watchlist.length,'Select at least one company.');
 return {version:2,strategy:dynamic?'sp500-forward':'compatibility',instruments:Object.fromEntries(catalog.map(x=>[x.symbol,x])),universe:options.universe||null,quoteHistory:{},signals:{},signalCursor:0,ignoredReports:0,mode,startedAt:now,updatedAt:now,initialCents:round(budget*100),cashCents:round(budget*100),realizedCents:0,feesCents:0,
  config:{middleCount:dynamic?Math.max(0,Math.min(20,Math.floor(Number(options.middleCount??10)))):10,taxPercent:percent,tradePercent,feeCents:50,slippageBps:5,minSources:2,maxQuoteAgeMs:dynamic?120000:15*60000,maxEventAgeMs:2*3600000,windowMs:3600000,cooldownMs:15*60000},
  watchlist,positions:{},quotes:{},events:[],trades:[],processed:[],history:[],running:false,lastPollAt:null,lastError:null};
}
function valueCents(units,price,up=false){const n=BigInt(units)*BigInt(price);return Number((n+(up?SCALE-1n:0n))/SCALE)}
export function summary(state){
 let holdingsCents=0,unrealizedCents=0;
 for(const [symbol,p] of Object.entries(state.positions)){const q=state.quotes[symbol];const v=q?valueCents(p.heldUnits,q.priceCents):p.basisCents;holdingsCents+=v;unrealizedCents+=v-p.basisCents;}
 const equityCents=state.cashCents+holdingsCents,pnlCents=equityCents-state.initialCents,taxEstimateCents=round(Math.max(0,state.realizedCents)*state.config.taxPercent/100);
 return {equityCents,holdingsCents,cashCents:state.cashCents,pnlCents,returnPercent:pnlCents/state.initialCents*100,realizedCents:state.realizedCents,unrealizedCents,taxEstimateCents,afterTaxEstimateCents:equityCents-taxEstimateCents};
}
export function keywordScore(text){
 const value=String(text).toLowerCase();
 const positive=/\b(announc(?:e|es|ed|ement)|launch(?:es|ed)?|approv(?:al|ed)|partnership|record revenue|profit growth|upgrade|wins contract|successful)\b/g;
 const negative=/\b(recall|complaint(?:s)?|defect(?:s|ive)?|failure|fails|lawsuit|outage|stops working|stopped working|overheat(?:ing)?|downgrade|fraud|investigation)\b/g;
 return Math.max(-3,Math.min(3,(value.match(positive)||[]).length-(value.match(negative)||[]).length));
}
function identity(e){if(e.channel==='social')return e.authorId?'social:'+e.authorId:null;try{return 'news:'+new URL(e.publisherUrl||e.url).hostname.replace(/^www\./,'')}catch{return null}}
function fingerprint(e){return e.title.toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
export function executePaperTrade(state,symbol,side,now=Date.now(),reason='Manual paper test'){
 assert(state.watchlist.includes(symbol),'Company is not in this watchlist.');
 const q=state.quotes[symbol];if(!q||!Number.isSafeInteger(q.priceCents)||q.priceCents<=0||q.asOf>now||now-q.asOf>state.config.maxQuoteAgeMs)return {ok:false,reason:'Waiting for a fresh USD quote.'};
 if(side==='BUY'&&state.strategy==='sp500-forward'&&!state.universe?.selectionSymbols.includes(symbol))return {ok:false,reason:'This company is monitored but is not selected for new buys.'};
 const fee=state.config.feeCents,bps=state.config.slippageBps;
 const p=state.positions[symbol]||{heldUnits:0,acquiredUnits:0,basisCents:0,lastBuyAt:null,lastSellAt:null};
 let units,price,cashChange,realized=0;
 if(side==='BUY'){
  const cap=round(summary(state).equityCents*.3),current=valueCents(p.heldUnits,q.priceCents);
  const spend=Math.min(round(state.initialCents*state.config.tradePercent/100),state.cashCents,Math.max(0,cap-current));
  if(spend<=fee)return {ok:false,reason:'Cash or the 30% per-company exposure limit prevents this buy.'};
  price=Math.ceil(q.priceCents*(10000+bps)/10000);units=Number(BigInt(spend-fee)*SCALE/BigInt(price));
  if(units<=0)return {ok:false,reason:'Trade is too small.'};
  const cost=valueCents(units,price,true)+fee;if(cost>state.cashCents)return {ok:false,reason:'Insufficient virtual cash.'};
  p.acquiredUnits+=units;p.heldUnits+=units;p.basisCents+=cost;p.lastBuyAt=now;cashChange=-cost;
 }else if(side==='SELL'){
  if(!p.heldUnits)return {ok:false,reason:'No virtual shares are held.'};
  const protectedUnits=Math.ceil(p.acquiredUnits*.6),available=p.heldUnits-protectedUnits;
  // The floor is anchored to ALL acquired shares, never the previous trade's remainder.
  units=Math.min(Math.floor(p.heldUnits*.25),available);
  if(units<=0)return {ok:false,reason:'Protected 60% floor reached. Cumulative sales cannot exceed 40% of acquired shares.'};
  price=Math.max(1,Math.floor(q.priceCents*(10000-bps)/10000));const proceeds=valueCents(units,price)-fee;
  if(proceeds<=0)return {ok:false,reason:'Proceeds would not cover the simulated commission.'};
  const basis=round(p.basisCents*units/p.heldUnits);p.basisCents-=basis;p.heldUnits-=units;p.lastSellAt=now;cashChange=proceeds;realized=proceeds-basis;state.realizedCents+=realized;
 }else throw Error('Unknown paper trade side.');
 state.cashCents+=cashChange;state.feesCents+=fee;state.positions[symbol]=p;
 const trade={id:'paper-'+now+'-'+state.trades.length,symbol,side,at:now,units,priceCents:price,cashChangeCents:cashChange,feeCents:fee,realizedCents:realized,reason,quoteAsOf:q.asOf,quoteSource:q.source};
 state.trades.push(trade);state.trades=state.trades.slice(-1000);return {ok:true,trade};
}
export function ingestFrame(input,frame,now=Date.now()){
 const state=structuredClone(input);assert(frame.mode===state.mode,'Demo data and observed data cannot be mixed. Reset into the intended mode first.');
 if(state.strategy==='sp500-forward'&&frame.universe){state.universe=frame.universe;state.instruments={...state.instruments,...Object.fromEntries(frame.universe.instruments.map(x=>[x.symbol,x]))};state.watchlist=frame.universe.instruments.map(x=>x.symbol);state.signalCursor=frame.nextSignalCursor||0;state.coverage=frame.coverage;}
 if(state.strategy==='sp500-forward'){state.config.maxQuoteAgeMs=120000;state.config.maxEventAgeMs=1800000;state.config.windowMs=1800000;}
 for(const q of frame.quotes||[]){if(!state.watchlist.includes(q.symbol)||q.currency!=='USD'||!Number.isFinite(q.price)||q.price<.01||q.price>1000000||!Number.isFinite(q.asOf)||q.asOf>now)continue;const old=state.quotes[q.symbol];if(!old||q.asOf>=old.asOf)state.quotes[q.symbol]={priceCents:round(q.price*100),asOf:q.asOf,source:String(q.source||'Unknown source').slice(0,100)};if(state.strategy==='sp500-forward'&&q.asOf>=state.startedAt&&now-q.asOf<=120000){state.quoteHistory??={};const samples=state.quoteHistory[q.symbol]||[];if(!samples.length||q.asOf>samples.at(-1).asOf)samples.push({price:q.price,asOf:q.asOf,observedAt:now,volume:q.volume||0});state.quoteHistory[q.symbol]=samples.slice(-60);}}

 const seen=new Set(state.processed.map(eventKey));state.processed=[...seen];
 for(const raw of frame.events||[]){
  if(!raw||typeof raw.id!=='string'||seen.has(eventKey(raw.id))||!state.watchlist.includes(raw.symbol)||typeof raw.title!=='string'||!Number.isFinite(raw.publishedAt))continue;
  if(state.strategy==='sp500-forward'&&(raw.publishedAt<state.startedAt||raw.publishedAt>now||now-raw.publishedAt>state.config.maxEventAgeMs)){state.ignoredReports=(state.ignoredReports||0)+1;continue;}
  const event={id:raw.id.slice(0,300),symbol:raw.symbol,title:raw.title.slice(0,1500),url:String(raw.url||'').slice(0,2000),publisherUrl:String(raw.publisherUrl||'').slice(0,2000),source:String(raw.source||'Unknown').slice(0,150),authorId:String(raw.authorId||'').slice(0,200),channel:raw.channel==='social'?'social':'news',publishedAt:raw.publishedAt,observedAt:now,score:keywordScore(raw.title),decision:'Observed',reason:'',consumed:false};
  const key=eventKey(raw.id);seen.add(key);state.processed.push(key);state.events.push(event);
 }
 state.processed=state.processed.slice(-5000);state.events=state.events.slice(-500);
 if(state.strategy==='sp500-forward')updateForwardSignals(state,now);
 for(const symbol of state.watchlist){
  const pending=state.events.filter(e=>e.symbol===symbol&&!e.consumed);
  for(const e of pending){if(e.publishedAt>now||e.publishedAt<state.startedAt||now-e.publishedAt>state.config.maxEventAgeMs){e.consumed=true;e.decision='Skipped';e.reason='Future, pre-start or stale report.';}else if(!e.score){e.consumed=true;e.decision='Hold';e.reason='No directional keyword signal.';}}
  const eligible=pending.filter(e=>!e.consumed&&now-e.publishedAt<=state.config.windowMs),sum=eligible.reduce((n,e)=>n+e.score,0);
  if(!eligible.length)continue;if(!sum){for(const e of eligible){e.decision='Hold';e.reason='Conflicting signals.';}continue;}
  const side=sum>0?'BUY':'SELL',evidence=eligible.filter(e=>Math.sign(e.score)===Math.sign(sum));
  const identities=new Set(evidence.map(identity).filter(Boolean)),texts=new Set(evidence.map(fingerprint));
  if(identities.size<state.config.minSources||texts.size<state.config.minSources){for(const e of evidence){e.decision='Hold';e.reason='Waiting for two distinct sources and non-identical reports.';}continue;}
  if(state.strategy==='sp500-forward'){const signal=state.signals[symbol];if(!signal?.statistics.ready){for(const e of evidence){e.decision='Hold';e.reason='Live statistics are warming up: 5 observations over at least 4 minutes.';}continue}if(Math.sign(signal.statistics.trendScore)!==Math.sign(sum)||Math.abs(signal.combined)<.25||signal.statistics.volatilityPct>5){for(const e of evidence){e.decision='Hold';e.reason='Live price statistics and sentiment do not provide an aligned eligible signal.';}continue}}
  const position=state.positions[symbol],last=side==='BUY'?position?.lastBuyAt:position?.lastSellAt;
  if(last!==null&&last!==undefined&&now-last<state.config.cooldownMs){for(const e of evidence){e.decision='Hold';e.reason='15-minute per-side cooldown.';}continue;}
  const result=executePaperTrade(state,symbol,side,now,'Keyword signal from '+identities.size+' distinct sources');
  for(const e of evidence){e.decision=result.ok?'Paper '+side:'Hold';e.reason=result.ok?'Simulated fill; no money moved.':result.reason;if(result.ok||!result.reason.includes('fresh USD quote'))e.consumed=true;}
 }
 if(state.strategy==='sp500-forward')applyRiskReductions(state,now);
 state.updatedAt=now;state.lastPollAt=now;state.lastError=frame.errors?.length?frame.errors.join(' · '):null;
 const totals=summary(state);state.history.push({at:now,equityCents:totals.equityCents,pnlCents:totals.pnlCents});state.history=state.history.slice(-500);return state;
}
export function demoFrames(start){
 const quote=(symbol,price,at)=>({symbol,price,currency:'USD',asOf:at,source:'Synthetic demo price — not a market quote'});
 const event=(id,symbol,title,at,channel='news')=>({id:'demo-'+id,symbol,title,publishedAt:at,channel,url:'https://example.'+(id.endsWith('a')?'com':'org')+'/demo/'+id,source:'Synthetic demo source',authorId:channel==='social'?'demo-author-'+id:''});
 const schedule=[
  {price:100,events:[['1a','SPCX','SpaceX announces a new service'],['1b','SPCX','SpaceX wins contract for a successful launch']]},
  {price:108,events:[['2a','SAMSUNG','Samsung announces a new partnership'],['2b','SAMSUNG','Samsung receives approval for a launch']]},
  {price:104,events:[['3a','SPCX','SpaceX service outage causes complaints'],['3b','SPCX','SpaceX faces investigation after failure'],['4a','SAMSUNG','Samsung phone stopped working: repeated complaints','social'],['4b','SAMSUNG','Galaxy overheating defect reported by customers','social']]},
  {price:101,events:[['5a','SPCX','New SpaceX outage complaints'],['5b','SPCX','SpaceX faces a new lawsuit after failure']]},
  {price:110,events:[['6a','SPCX','SpaceX faces more outage complaints'],['6b','SPCX','New investigation into SpaceX failure']]}
 ];
 return schedule.map((step,i)=>{const at=start+i*20*60000;return {mode:'demo',at,quotes:[quote('SPCX',step.price,at),quote('SAMSUNG',i<2?50:45,at),quote('AAPL',200+i,at)],events:step.events.map(([id,symbol,title,channel])=>event(id,symbol,title,at,channel))};});
}

function updateForwardSignals(state,now){state.signals??={};for(const symbol of state.watchlist){const statistics=marketStatistics(state.quoteHistory?.[symbol]||[]),events=state.events.filter(e=>e.symbol===symbol&&e.publishedAt>=state.startedAt&&now-e.publishedAt<=1800000),distinct=new Map();for(const e of events){const who=identity(e);if(who)distinct.set(who,e.score)}const sentiment=distinct.size?[...distinct.values()].reduce((a,b)=>a+b,0)/distinct.size:0,combined=statistics.ready ? .55*statistics.trendScore+.45*sentiment : 0;state.signals[symbol]={statistics,sentiment,combined,evidenceCount:distinct.size,bias:!statistics.ready?'Warming up':combined>=.25?'Buy bias':combined<=-.25?'Sell bias':'Hold',reason:!statistics.ready?statistics.reason:'Observed momentum, volatility and recent distinct-source sentiment; not a calibrated forecast.'};}if(state.universe)state.universe=refreshUniverseSelection(state.universe,state.signals);}
function applyRiskReductions(state,now){for(const [symbol,position] of Object.entries(state.positions)){const stats=state.signals[symbol]?.statistics;if(!stats?.ready||stats.trendScore>=-1.2||stats.zScore>=-1||position.lastSellAt!==null&&now-position.lastSellAt<state.config.cooldownMs)continue;executePaperTrade(state,symbol,'SELL',now,'Forward statistical risk reduction; protected 60% floor still applies.');}}
