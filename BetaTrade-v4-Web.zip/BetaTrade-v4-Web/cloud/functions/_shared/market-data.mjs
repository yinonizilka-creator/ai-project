import {INSTRUMENTS} from './simulator-engine.js';
const cache=new Map();
const xml=value=>String(value||'').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;|&#39;/g,"'").trim();
const tag=(text,name)=>xml(text.match(new RegExp('<'+name+'(?:\\s[^>]*)?>([\\s\\S]*?)<\\/'+name+'>','i'))?.[1]||'');
export function parseNewsRss(text,symbol){
 return [...text.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0,30).map(([,item])=>{
  const url=tag(item,'link'),source=item.match(/<source\s+url=["']([^"']+)["'][^>]*>([\s\S]*?)<\/source>/i);
  return {id:'rss:'+symbol+':'+(tag(item,'guid')||url),symbol,title:tag(item,'title'),url,source:xml(source?.[2]||'Google News RSS'),publisherUrl:xml(source?.[1]||''),channel:'news',publishedAt:Date.parse(tag(item,'pubDate'))};
 }).filter(e=>e.title&&Number.isFinite(e.publishedAt)&&/^https:\/\//.test(e.url));
}
export async function collectLiveFrame(watchlist,{key='',now=Date.now(),fetchImpl=fetch,instruments=INSTRUMENTS,includeQuotes=true}={}){
 const errors=[],quotes=[],events=[],sources={news:'pending',social:'pending',quotes:key?'pending':'not configured'};
 async function read(url,type='json',headers={},ttl=60000){
  const cacheKey=type+url;const entry=cache.get(cacheKey);if(fetchImpl===fetch&&entry&&entry.until>now)return entry.value;
  const response=await fetchImpl(url,{headers,signal:AbortSignal.timeout(12000)});if(!response.ok)throw Error('HTTP '+response.status);
  const text=await response.text();if(text.length>2000000)throw Error('Response exceeds 2 MB.');const value=type==='json'?JSON.parse(text):text;
  if(fetchImpl===fetch){cache.set(cacheKey,{value,until:now+ttl});if(cache.size>100)for(const [k,v] of cache)if(v.until<now)cache.delete(k);}return value;
 }
 await Promise.all(watchlist.map(async symbol=>{
  const instrument=instruments.find(x=>x.symbol===symbol);if(!instrument)return;
  const results=await Promise.allSettled([
   read('https://news.google.com/rss/search?'+new URLSearchParams({q:(instrument.query||instrument.name)+' when:1d',hl:'en-US',gl:'US',ceid:'US:en'}),'text',{},300000),
   read('https://public.api.bsky.app/xrpc/app.bsky.feed.searchPosts?'+new URLSearchParams({q:instrument.query||instrument.name,limit:'20',sort:'latest'}),'json',{},120000),
   includeQuotes&&key&&instrument.currency==='USD'&&instrument.quoteSymbol?read('https://finnhub.io/api/v1/quote?'+new URLSearchParams({symbol:instrument.quoteSymbol}),'json',{'X-Finnhub-Token':key},60000):Promise.resolve(null)
  ]);
  if(results[0].status==='fulfilled'){events.push(...parseNewsRss(results[0].value,symbol));sources.news='responded';}else errors.push(instrument.name+' news: '+results[0].reason.message);
  if(results[1].status==='fulfilled'){
   sources.social='responded';for(const post of results[1].value.posts||[]){const id=String(post.uri||''),author=post.author?.did||'',rkey=id.split('/').at(-1),publishedAt=Date.parse(post.record?.createdAt||post.indexedAt);if(!id||!author||!Number.isFinite(publishedAt))continue;events.push({id:'bsky:'+symbol+':'+id,symbol,title:String(post.record?.text||'').slice(0,1500),url:'https://bsky.app/profile/'+encodeURIComponent(author)+'/post/'+encodeURIComponent(rkey),source:'Bluesky public post',authorId:author,channel:'social',publishedAt});}
  }else{
   errors.push(instrument.name+' Bluesky: '+results[1].reason.message);
   try{
    const hashtag=instrument.symbol==='SAMSUNG'?'samsung':instrument.name.toLowerCase().replace(/[^a-z0-9]/g,'');
    const posts=await read('https://mastodon.social/api/v1/timelines/tag/'+encodeURIComponent(hashtag)+'?limit=20','json',{},120000);
    if(!Array.isArray(posts))throw Error('Unexpected public timeline response.');
    sources.social='Mastodon public hashtag';
    for(const item of posts){const post=item.reblog||item,publishedAt=Date.parse(post.created_at);if(post.visibility!=='public'||!post.account?.url||!Number.isFinite(publishedAt))continue;const text=xml(post.content);const terms={SPCX:['spacex','starlink','starship','spcx'],AAPL:['iphone','aapl','apple inc','macbook','ipad'],MSFT:['microsoft','msft','azure','windows'],TSLA:['tesla','tsla'],SAMSUNG:['samsung','galaxy']}[symbol]||instrument.terms||[symbol.toLowerCase(),instrument.name.toLowerCase()];if(!terms.some(term=>text.toLowerCase().includes(term)))continue;events.push({id:'mastodon:'+symbol+':'+post.id,symbol,title:xml(post.content).slice(0,1500),url:String(post.url||''),source:'Mastodon public hashtag',authorId:'mastodon:'+post.account.url,channel:'social',publishedAt});}
   }catch(e){errors.push(instrument.name+' Mastodon: '+e.message);}
  }
  if(results[2].status==='fulfilled'&&results[2].value){const q=results[2].value;if(Number(q.c)>0&&Number(q.t)>0){quotes.push({symbol,price:Number(q.c),currency:'USD',asOf:Number(q.t)*1000,source:'Finnhub · quote timeliness depends on plan/exchange'});sources.quotes='responded';}else errors.push(instrument.name+': provider returned no usable quote.');}
  else if(results[2].status==='rejected')errors.push(instrument.name+' quote: '+results[2].reason.message);
  if(includeQuotes&&!instrument.quoteSymbol)errors.push(instrument.name+': market symbol, pricing entitlement and USD conversion are not connected. Observation only.');
 }));
 if(sources.news==='pending')sources.news='unavailable';if(sources.social==='pending')sources.social='unavailable';
 if(includeQuotes&&!key)errors.push('No price provider key: news/posts can be observed, but no live-data paper trades will be filled.');
 return {mode:'live',quotes,events,errors,sources,fetchedAt:now};
}
