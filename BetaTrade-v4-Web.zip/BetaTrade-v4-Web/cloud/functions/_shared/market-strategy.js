export const UNIVERSE_POLICY={top:20,bottom:10,middle:10,pool:40};
export function normalizeMembers(members,quotes,now=Date.now()){
 const quoteMap=new Map(quotes.map(q=>[String(q.symbol||'').toUpperCase(),q])),companies=new Map(),missing=[];
 for(const member of members){const symbol=String(member.symbol||'').toUpperCase();if(!/^[A-Z0-9][A-Z0-9.-]{0,14}$/.test(symbol))continue;const name=String(member.name||member.companyName||symbol);const cik=String(member.cik||'').replace(/^0+/,'');const key=cik?'cik:'+cik:'name:'+name.toLowerCase().replace(/\bclass\s+[abc]\b/g,'').replace(/[^a-z0-9]/g,'');if(!companies.has(key))companies.set(key,{key,name,sector:member.sector||'Unknown',members:[]});companies.get(key).members.push({symbol,quote:quoteMap.get(symbol)});}
 const result=[];for(const company of companies.values()){
  const valid=company.members.filter(x=>Number.isFinite(Number(x.quote?.marketCap))&&Number(x.quote.marketCap)>0&&Number(x.quote.timestamp)>0&&Number(x.quote.timestamp)*1000<=now);
  if(!valid.length){missing.push(company.name);continue}valid.sort((a,b)=>Number(b.quote.volume||0)-Number(a.quote.volume||0)||a.symbol.localeCompare(b.symbol));const representative=valid[0],cap=Math.max(...valid.map(x=>Number(x.quote.marketCap)));
  result.push({symbol:representative.symbol,name:company.name,companyKey:company.key,sector:company.sector,marketCap:cap,capAsOf:Number(representative.quote.timestamp)*1000,quoteSymbol:representative.symbol,currency:'USD',query:company.name,terms:[representative.symbol.toLowerCase(),...company.name.toLowerCase().replace(/\b(incorporated|inc|corp|corporation|company|group|holdings|plc|ltd|class|the|co)\b/g,'').split(/[^a-z0-9]+/).filter(x=>x.length>=4)].slice(0,4)});
 }
 result.sort((a,b)=>b.marketCap-a.marketCap||a.symbol.localeCompare(b.symbol));result.forEach((x,i)=>x.rank=i+1);return {ranked:result,missing,companyCount:companies.size};
}
export function middleCandidates(ranked,count=UNIVERSE_POLICY.pool){const middle=ranked.slice(UNIVERSE_POLICY.top,-UNIVERSE_POLICY.bottom);if(middle.length<=count)return middle;return Array.from({length:count},(_,i)=>middle[Math.floor((i+.5)*middle.length/count)]);}
export function marketStatistics(samples=[]){
 const data=samples.filter(x=>Number.isFinite(x.price)&&x.price>0).slice(-60);if(data.length<5||data.at(-1).asOf-data[0].asOf<4*60000)return {ready:false,samples:data.length,reason:'Warming up: needs at least 5 distinct live observations across 4 minutes.'};
 const prices=data.map(x=>x.price),last=prices.at(-1),mean=prices.reduce((a,b)=>a+b,0)/prices.length,variance=prices.reduce((n,p)=>n+(p-mean)**2,0)/prices.length,sd=Math.sqrt(variance);
 const returns=prices.slice(1).map((p,i)=>(p/prices[i]-1)*100),rmean=returns.reduce((a,b)=>a+b,0)/returns.length,volatility=Math.sqrt(returns.reduce((n,r)=>n+(r-rmean)**2,0)/returns.length),momentum=(last/prices[0]-1)*100;
 const short=prices.slice(-3).reduce((a,b)=>a+b,0)/3,long=prices.slice(-Math.min(20,prices.length)).reduce((a,b)=>a+b,0)/Math.min(20,prices.length),trendGap=(short/long-1)*100;
 const trendScore=Math.max(-3,Math.min(3,momentum/2+trendGap));return {ready:true,samples:data.length,momentumPct:momentum,volatilityPct:volatility,zScore:sd?(last-mean)/sd:0,trendScore,asOf:data.at(-1).asOf,windowStart:data[0].asOf};
}
export function selectUniverse(ranked,signals={},middleCount=10){
 if(ranked.length<40)throw Error('A complete current index snapshot is required before selecting companies.');
 middleCount=Math.max(0,Math.min(20,Math.floor(middleCount)));const pool=middleCandidates(ranked),top=ranked.slice(0,20),bottom=ranked.slice(-10),sectorCounts=new Map();
 const scored=pool.map((company,i)=>{const signal=signals[company.symbol]||{},stats=signal.statistics,sentiment=Number(signal.sentiment||0),combined=stats?.ready ? .55*stats.trendScore+.45*sentiment : 0;const strength=stats?.ready?Math.abs(combined)/(1+stats.volatilityPct):0;return {...company,strength,combined,statistics:stats||{ready:false,samples:0},sentiment,poolIndex:i};}).sort((a,b)=>b.strength-a.strength||a.poolIndex-b.poolIndex);
 const middle=[];for(const item of scored){if(middle.length>=middleCount)break;const count=sectorCounts.get(item.sector)||0;if(count>=3)continue;middle.push(item);sectorCounts.set(item.sector,count+1)}for(const item of scored)if(middle.length<middleCount&&!middle.some(x=>x.symbol===item.symbol))middle.push(item);
 const describe=(company,cohort)=>({...company,cohort,selectionReason:cohort==='top'?'One of the 20 largest index companies by provider market cap.':cohort==='bottom'?'One of the 10 smallest index companies by provider market cap.':company.statistics?.ready?'Middle candidate: observed momentum/volatility and recent sentiment; score is not a probability.':'Provisional middle sample by rank and sector; live statistics are warming up.'});
 return {selected:[...top.map(x=>describe(x,'top')),...bottom.map(x=>describe(x,'bottom')),...middle.map(x=>describe(x,'middle'))],pool,policy:{top:20,bottom:10,middle:middleCount},rankedCount:ranked.length};
}
export function refreshUniverseSelection(snapshot,signals={}){
 const core=snapshot.selected.filter(x=>x.cohort!=='middle'),pool=snapshot.pool||[],count=snapshot.policy?.middle??10;
 const syntheticRanks=[...core.filter(x=>x.cohort==='top'),...pool,...core.filter(x=>x.cohort==='bottom')];
 // Preserve the actual ranks and membership while re-scoring only the existing middle pool.
 const selection=selectUniverse(syntheticRanks,signals,count);return {...snapshot,selected:selection.selected,selectionSymbols:selection.selected.map(x=>x.symbol)};
}
