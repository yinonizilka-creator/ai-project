-- DEPLOYMENT STEP ONLY: do not run before deploying and verifying market-lab.
-- In Supabase Vault, store betatrade_worker_url (the function URL) and
-- betatrade_worker_key (the SAME high-entropy value as the function's
-- MARKET_WORKER_KEY runtime secret). Never put those values in this file.
-- Enable pg_cron and pg_net through your project's supported settings first.
-- Named cron.schedule replaces the matching job; inspect existing jobs first.
do $$
begin
 if not exists(select 1 from vault.decrypted_secrets where name='betatrade_worker_url')
 or not exists(select 1 from vault.decrypted_secrets where name='betatrade_worker_key')
 then raise exception 'Configure the worker URL/key in Vault before scheduling.'; end if;
end $$;
select cron.schedule('betatrade-market-lab','* * * * *', $job$
 select net.http_post(
  url := (select decrypted_secret from vault.decrypted_secrets where name='betatrade_worker_url'),
  headers := jsonb_build_object('Content-Type','application/json','x-market-worker-key',
   (select decrypted_secret from vault.decrypted_secrets where name='betatrade_worker_key')),
  body := '{"action":"cron"}'::jsonb,
  timeout_milliseconds := 120000
 );
$job$);
