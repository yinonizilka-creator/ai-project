const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('betaDesktop',{
 isDesktop:true,
 browserState:()=>ipcRenderer.invoke('browser:state'),
 navigate:value=>ipcRenderer.invoke('browser:navigate',value),
 newTab:value=>ipcRenderer.invoke('browser:new-tab',value),
 selectTab:id=>ipcRenderer.invoke('browser:select-tab',id),
 closeTab:id=>ipcRenderer.invoke('browser:close-tab',id),
 back:()=>ipcRenderer.invoke('browser:back'),forward:()=>ipcRenderer.invoke('browser:forward'),reload:()=>ipcRenderer.invoke('browser:reload'),
 browserBounds:bounds=>ipcRenderer.invoke('browser:bounds',bounds),
 external:url=>ipcRenderer.invoke('desktop:external',url),
 setTheme:value=>ipcRenderer.invoke('desktop:theme',value),
 marketSettings:()=>ipcRenderer.invoke('desktop:market-settings'),
 saveMarketKey:value=>ipcRenderer.invoke('desktop:market-key',value),
 uiModal:value=>ipcRenderer.invoke('desktop:modal',value),
 onFocusAddress:callback=>{const listener=()=>callback();ipcRenderer.on('browser:focus-address',listener);return()=>ipcRenderer.removeListener('browser:focus-address',listener)},
 onBrowserState:callback=>{const listener=(_event,state)=>callback(state);ipcRenderer.on('browser:changed',listener);return()=>ipcRenderer.removeListener('browser:changed',listener)}
});
