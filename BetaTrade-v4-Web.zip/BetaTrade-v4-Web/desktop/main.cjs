const {app,BrowserWindow,WebContentsView,ipcMain,session,shell,nativeTheme,safeStorage,dialog}=require('electron');
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const {browserAddress,trustedPage,safeBounds}=require('./browser-policy.cjs');
const ROOT=path.resolve(__dirname,'..');app.setName('BetaTrade');app.setAppUserModelId('BetaTrade.Desktop');
const PROFILE=process.env.BETATRADE_USER_DATA||path.join(app.getPath('appData'),'BetaTrade');fs.mkdirSync(PROFILE,{recursive:true});
app.setPath('userData',PROFILE);app.setPath('crashDumps',path.join(PROFILE,'crash-dumps'));
const prefsFile=path.join(PROFILE,'preferences.json'),keyFile=path.join(PROFILE,'market-key.bin');
let prefs={port:17658,theme:'dark'};try{prefs={...prefs,...JSON.parse(fs.readFileSync(prefsFile,'utf8'))}}catch{}
if(!Number.isInteger(prefs.port)||prefs.port<1024||prefs.port>65535)prefs.port=17658;
const origin='http://127.0.0.1:'+prefs.port;let win,backend,activeId=null,tabs=[],bounds={x:0,y:0,width:0,height:0,visible:false},modal=false,quitting=false;
const savePrefs=()=>fs.writeFileSync(prefsFile,JSON.stringify(prefs),{mode:0o600});
function storedKey(){try{return safeStorage.isEncryptionAvailable()?safeStorage.decryptString(fs.readFileSync(keyFile)):''}catch{return ''}}
async function startBackend(){
 const child=spawn(process.execPath,[path.join(ROOT,'server.cjs')],{cwd:ROOT,windowsHide:true,env:{...process.env,ELECTRON_RUN_AS_NODE:'1',NODE_ENV:'development',APP_ORIGIN:origin,HOST:'127.0.0.1',PORT:String(prefs.port),DATA_DIR:path.join(PROFILE,'server-data'),FMP_API_KEY:storedKey()||process.env.FMP_API_KEY||''},stdio:['ignore','pipe','pipe']});backend=child;
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{child.kill();reject(Error('The local workspace server did not become ready.'))},20000);let errors='';child.stderr.on('data',data=>{errors=(errors+data.toString()).slice(-1500)});child.stdout.on('data',data=>{if(data.toString().includes('BetaTrade is ready:')){clearTimeout(timer);resolve()}});child.once('error',e=>{clearTimeout(timer);reject(e)});child.once('exit',code=>{clearTimeout(timer);reject(Error('Workspace server exited ('+code+'). '+(errors.includes('EADDRINUSE')?'Its dedicated local port is already in use. Close the other BetaTrade instance.':'Check that the application files and data folder are accessible.')))});});
}
async function stopBackend(){const child=backend;backend=null;if(!child)return;await new Promise(resolve=>{const timer=setTimeout(()=>{try{child.kill()}catch{}resolve()},4000);child.once('exit',()=>{clearTimeout(timer);resolve()});try{child.kill()}catch{clearTimeout(timer);resolve()}})}
function active(){return tabs.find(t=>t.id===activeId)}
function snapshot(){const selected=active(),wc=selected?.view?.webContents;return {activeId,tabs:tabs.map(t=>({id:t.id,title:t.view?.webContents.getTitle()||t.title||'New tab',url:t.view?.webContents.getURL()||t.url||'',loading:t.view?.webContents.isLoading()||false})),canBack:!!wc?.navigationHistory.canGoBack(),canForward:!!wc?.navigationHistory.canGoForward(),error:selected?.error||''}}
function publish(){if(win&&!win.isDestroyed())win.webContents.send('browser:changed',snapshot())}
function syncViews(){if(!win||win.isDestroyed())return;let onBrowser=false;try{onBrowser=new URL(win.webContents.getURL()).pathname==='/browser.html'}catch{}for(const t of tabs){if(!t.view)continue;const visible=t.id===activeId&&onBrowser&&bounds.visible&&!modal&&bounds.width>20&&bounds.height>20;t.view.setVisible(visible);if(visible)t.view.setBounds({x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height});}}
function guard(event,browserOnly=false){if(!win||event.sender!==win.webContents||event.senderFrame!==win.webContents.mainFrame||!trustedPage(event.senderFrame.url,origin))throw Error('Untrusted application context.');if(browserOnly&&new URL(event.senderFrame.url).pathname!=='/browser.html')throw Error('Open Web Desk first.');}
function makeView(tab){
 const view=new WebContentsView({webPreferences:{partition:'persist:betatrade-web',nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,allowRunningInsecureContent:false}});tab.view=view;win.contentView.addChildView(view);view.setVisible(false);
 const wc=view.webContents;wc.on('before-input-event',(event,input)=>{if(input.type!=='keyDown'||!input.control)return;const key=input.key.toLowerCase();if(key==='l'){event.preventDefault();win.webContents.focus();win.webContents.send('browser:focus-address')}if(key==='t'){event.preventDefault();newTab();win.webContents.focus();win.webContents.send('browser:focus-address')}});
 const navigateGuard=(event,url)=>{try{browserAddress(url||event.url)}catch{event.preventDefault();tab.error='That navigation is not a supported public HTTPS website.';publish()}};
 wc.on('will-navigate',navigateGuard);wc.on('will-redirect',navigateGuard);
 wc.setWindowOpenHandler(({url})=>{try{newTab(browserAddress(url))}catch{}return {action:'deny'}});
 for(const event of ['did-navigate','did-navigate-in-page','page-title-updated','did-start-loading','did-stop-loading'])wc.on(event,()=>{if(!wc.isDestroyed()){tab.url=wc.getURL();publish()}});
 wc.on('did-fail-load',(_e,code,description,_url,isMainFrame)=>{if(isMainFrame&&code!==-3){tab.error='The site could not load: '+description+'. You can open it in your system browser.';publish()}});
 return view;
}
async function navigate(value){let tab=active();if(!tab){tab={id:crypto.randomUUID(),url:'',title:'New tab',error:''};tabs.push(tab);activeId=tab.id}const url=browserAddress(value);tab.error='';if(!url){syncViews();publish();return snapshot()}if(!tab.view)makeView(tab);tab.url=url;syncViews();publish();tab.view.webContents.loadURL(url).catch(e=>{if(!tab.view.webContents.isDestroyed()&&!e.message.includes('ERR_ABORTED')){tab.error='Unable to load this website. Its sign-in or network policy may require your system browser.';publish()}});return snapshot();}
function newTab(value=''){if(tabs.length>=12)throw Error('Close a tab before opening more than 12 tabs.');const tab={id:crypto.randomUUID(),url:'',title:'New tab',error:''};tabs.push(tab);activeId=tab.id;if(value)void navigate(value);else{syncViews();publish()}return snapshot()}
function installIpc(){
 const handle=(name,fn,browserOnly=false)=>ipcMain.handle(name,(event,value)=>{guard(event,browserOnly);return fn(value)});
 handle('browser:state',()=>snapshot(),true);handle('browser:navigate',navigate,true);handle('browser:new-tab',newTab,true);
 handle('browser:select-tab',id=>{if(!tabs.some(t=>t.id===id))throw Error('Unknown tab.');activeId=id;syncViews();publish();return snapshot()},true);
 handle('browser:close-tab',id=>{const tab=tabs.find(t=>t.id===id);if(!tab)return snapshot();if(tab.view){win.contentView.removeChildView(tab.view);if(!tab.view.webContents.isDestroyed())tab.view.webContents.close()}tabs=tabs.filter(t=>t.id!==id);if(activeId===id)activeId=tabs.at(-1)?.id||null;if(!tabs.length)newTab();syncViews();publish();return snapshot()},true);
 for(const [name,method] of [['back','goBack'],['forward','goForward']])handle('browser:'+name,()=>{const h=active()?.view?.webContents.navigationHistory;if(h&&(name==='back'?h.canGoBack():h.canGoForward()))h[method]();return snapshot()},true);
 handle('browser:reload',()=>{const wc=active()?.view?.webContents;if(wc){if(wc.isLoading())wc.stop();else wc.reload()}return snapshot()},true);
 handle('browser:bounds',input=>{const [width,height]=win.getContentSize();bounds=safeBounds(input,width,height);syncViews();return true},true);
 handle('desktop:external',value=>shell.openExternal(browserAddress(value)));
 handle('desktop:theme',value=>{if(!['dark','light','system'].includes(value))throw Error('Invalid theme.');prefs.theme=value;nativeTheme.themeSource=value;savePrefs();win.setBackgroundColor(nativeTheme.shouldUseDarkColors?'#212121':'#fafafa');return true});
 handle('desktop:modal',value=>{modal=value===true;syncViews();return true});
 handle('desktop:market-settings',()=>({configured:!!storedKey(),encryptionAvailable:safeStorage.isEncryptionAvailable()}));
 handle('desktop:market-key',async value=>{const key=String(value||'').trim();if(!/^[A-Za-z0-9_-]{10,256}$/.test(key))throw Error('Enter a valid provider key.');if(!safeStorage.isEncryptionAvailable())throw Error('Windows secure storage is unavailable. The key was not saved.');fs.writeFileSync(keyFile,safeStorage.encryptString(key),{mode:0o600});await stopBackend();await startBackend();return {configured:true}});
}
if(!app.requestSingleInstanceLock()){app.quit()}else{
 app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus()}});
 app.whenReady().then(async()=>{
  nativeTheme.themeSource=['dark','light','system'].includes(prefs.theme)?prefs.theme:'dark';savePrefs();
  const remote=session.fromPartition('persist:betatrade-web');remote.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));remote.setPermissionCheckHandler(()=>false);
  await startBackend();
  win=new BrowserWindow({width:1440,height:1000,minWidth:900,minHeight:650,title:'BetaTrade',icon:path.join(ROOT,'dist/assets/betatrade-icon.png'),backgroundColor:'#212121',autoHideMenuBar:true,show:false,webPreferences:{partition:'persist:betatrade-app',preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true}});
  installIpc();win.webContents.setWindowOpenHandler(({url})=>{try{void shell.openExternal(browserAddress(url))}catch{}return {action:'deny'}});
  win.webContents.on('will-navigate',(event,url)=>{url=url||event.url;for(const tab of tabs)tab.view?.setVisible(false);if(!trustedPage(url,origin)){event.preventDefault();try{void shell.openExternal(browserAddress(url))}catch{}}});
  win.webContents.on('did-start-navigation',()=>{for(const tab of tabs)tab.view?.setVisible(false)});
  win.on('resize',()=>syncViews());win.once('ready-to-show',()=>win.show());
  win.on('closed',()=>{for(const tab of tabs)if(tab.view&&!tab.view.webContents.isDestroyed())tab.view.webContents.close();win=null;app.quit()});
  await win.loadURL(origin+'/index.html');
 }).catch(e=>{dialog.showErrorBox('BetaTrade could not start',e.message);app.quit()});
 app.on('before-quit',event=>{if(backend&&!quitting){event.preventDefault();quitting=true;void stopBackend().finally(()=>app.quit())}});
 app.on('window-all-closed',()=>app.quit());
}
